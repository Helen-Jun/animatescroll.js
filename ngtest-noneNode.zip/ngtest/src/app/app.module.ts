/*
 * Angular
 */
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';

import { routing } from './app.routing';
import {LocationStrategy, HashLocationStrategy} from '@angular/common';
import { FormsModule } from '@angular/forms';

import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule, BsDatepickerModule, TimepickerModule, PaginationModule } from 'ngx-bootstrap';
import { ButtonsModule } from 'ngx-bootstrap';
import {DemoModalStaticComponent} from "./app.component";
import {DataTableComponent} from "./app.component";
import * as $ from 'jquery';
/*
 * Components
 */
import { LoginComponent } from './app.component';
import {ProtectedComponent} from './login/ProtectedComponent';
import { TaskComponent } from './task/task.component';
import { TeacherComponent } from './teacher/teacher.component';
import { CourseComponent } from './course/course.component';
import { CommunityComponent } from './community/community.component';
import { RoleComponent } from './role/role.component';
/*
 * Services
 */
import {AUTH_PROVIDERS} from './services/AuthService';
import {LoggedInGuard} from './guards/loggedIn.guard';

@NgModule({
  declarations: [
    AppComponent,
    DemoModalStaticComponent,

    DataTableComponent,
    LoginComponent,
    ProtectedComponent,
    TaskComponent,
    TeacherComponent,
    CourseComponent,
    CommunityComponent,
    RoleComponent
  ],
  imports: [
    BsDropdownModule.forRoot(),
    ModalModule.forRoot(),
    ButtonsModule.forRoot(),
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    PaginationModule.forRoot(),
    BrowserModule,
    routing,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    AUTH_PROVIDERS,
    LoggedInGuard,
    { provide: LocationStrategy, useClass: HashLocationStrategy },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }


