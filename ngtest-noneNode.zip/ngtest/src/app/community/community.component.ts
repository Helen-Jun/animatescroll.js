import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { Task } from '../task/task.model';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-community',
  templateUrl: './community.component.html',
  styleUrls: ['./community.component.css',
        '../task/task.component.css',
        '../app.component.css']
})
export class CommunityComponent implements OnInit {

    private headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    url = 'http://edu.xk.com/xkapi'; 
    addOrEdit:string = 'add';

    data = [];
    array = [];

    size: number = 10;    
    index: number;     //要先声明 

    searchCode:string = '';
    searchTeacher:string = '';
    searchContact:string = '';
    
    areaArr = [];
    id: number = 0;
    areaId: number = 0; // 被选中的区

    code:string = '';
    name:string = '';
    contactBody:string = '';
    contactPhone:string = '';
    communities:string = '';

    content:string = '';
    deleteId : number = 0;
    isEmpty:boolean = false;
    /* 分页，start*/
    maxSize: number = 5;
    bigTotalItems: number = 50000; //总数
    bigCurrentPage: number = 1; //当前页
    numPages: number = 0;   //总页数
   
    pageChanged(event: any): void {
      this.bigCurrentPage = event.page;
      this.getList(event.page, 10);
      console.log('Page changed to: ' + event.page);
      console.log('Number items per page: ' + event.itemsPerPage);
    }
    /* 分页，end*/
    constructor(private http: HttpClient){ }

    ngOnInit() {
      //this.getList(1,10)  //要this
      this.getArea();
    }

    getList(pagenumber, pagesize) {

        let reqParam = `areaId=${this.areaId}`;
        return this.http.post(`${this.url}/community/findByAreaId`, reqParam, { 'headers': this.headers} ).subscribe(
          result => {
              if(result) {
                  if (result['status'] == 200) {
                      this.array = result['data'];
                  } else {
                      console.log(result['desc']);
                  }
              }
          }
      );
    }

    getArea (){
      return this.http.get(`${this.url}/area/findAll`).subscribe(
          result => {
              if(result) {
                  if (result['status'] == 200) {
                      this.areaArr = result['data'];
                      if ( this.areaArr.length >=1) {
                        this.areaId = this.areaArr[0].id; // 默认第一项
                        //调用list
                        this.getList(1, 10);
                      }
                  } else {
                      console.log(result['desc']);
                  }
              }
          }
      );
    }
    change () {
        this.getList(1,10);
        this.bigCurrentPage = 1;
    }
    // search
    search() {
        this.bigCurrentPage = 1;
        this.getList(1, 10);
    }
    clear() {
        this.searchCode = '';
        this.searchTeacher = '';
        this.searchContact= '';

        this.search();
    }

    //添加和编辑 提交按钮
    onSubmit(id, name, contactBody, contactPhone, content, addModal):void {
        let reqUrl = this.addOrEdit === 'add' ? `${this.url}/community/add` : `${this.url}/community/update`;

        if (!(name && contactPhone && contactBody && content)) {
            this.isEmpty= true;
            return;
        }
        this.isEmpty= false;
        this.http.get(`${reqUrl}?id=${id}&name=${name}&contactBody=${contactBody}&contactPhone=${contactPhone}&content=${content}&areaId=${this.areaId}`).subscribe(
          result => {
            if(result) {
              if (result['status'] == 200) {
                  this.getList(1, 10); //要this
                  this.bigCurrentPage = 1;
                  addModal.hide();
              } else {
                  console.log(result['desc']);
              }
            }
          }
        );
    }
    ngChangedFn():void {
        this.isEmpty = false;
    }
    //添加
    addNew(addModal) {
        addModal.show();

        this.addOrEdit = 'add';
        this.id = 0;
        this.name = '';
        this.contactBody = '';
        this.contactPhone = '';
        this.content = '';
    }
    // 编辑 按钮
    edit(item, addModal) {  
        console.log('item:');
        console.log(item);

        addModal.show();
        
        this.addOrEdit = 'edit';
        this.id = item.id;
        this.name = item.name;
        this.contactBody = item.contactBody;
        this.contactPhone = item.contactPhone;

        this.content = item.content;
    }
    //删除按钮
    delete(item, deleteModal){  
        deleteModal.show();
        console.log('delete');
        this.deleteId= item.id;
        
    }
    //删除 确认
    deleteConfirm(item,deleteModal) {  
        console.log('item:');
        console.log(item);
        return this.http.get(`${this.url}/community/delete?id=${this.deleteId}`).subscribe(
          result => {
              if(result) {
                this.getList(1, 10)  //要this
                this.bigCurrentPage = 1;
                deleteModal.hide();
              } else {
                  console.log(result['desc']);
              }
          }
      );
    }
}
